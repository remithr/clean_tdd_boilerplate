import 'package:clear_architecture/features/user_authentication/domain/entities/user_details_entity.dart';
import 'package:clear_architecture/features/user_authentication/domain/repositories/user_repository.dart';
import 'package:clear_architecture/features/user_authentication/domain/usecases/authenticate_user.dart';
import 'package:dartz/dartz.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';

class MockAuthenticateUserRepository extends Mock implements UserRepository {}

void main() {
  late AuthenticateUser usecase;
  late MockAuthenticateUserRepository mockUserAuthenticationRepository;
  setUp(() {
    mockUserAuthenticationRepository = MockAuthenticateUserRepository();
    usecase = AuthenticateUser(repository: mockUserAuthenticationRepository);
  });

  const String temail = 'rem@yopmail.com';
  const String tpassword = '123456';
  const UserDetailsEntity tUserDetailsRepository = UserDetailsEntity(
      email: 'remithr@yopmail.com', name: 'Remith ', userID: '1');

  test('should get user details on login success', () async {
    // arrange
    when(mockUserAuthenticationRepository.loginUser(temail, tpassword))
        .thenAnswer((_) async => const Right(tUserDetailsRepository));
    // act
    final result = await usecase.execute(email: temail, password: tpassword);
    print(result);
    // assert
    expect(result, const Right(tUserDetailsRepository));
    verify(mockUserAuthenticationRepository.loginUser(temail, tpassword));
    verifyNoMoreInteractions(mockUserAuthenticationRepository);
  });
}
