import 'package:dartz/dartz.dart';

import '../../../../core/error/failures.dart';
import '../entities/user_details_entity.dart';
import '../repositories/user_repository.dart';

class AuthenticateUser {
  final UserRepository repository;
  AuthenticateUser({
    required this.repository,
  });

  Future<Either<Failure, UserDetailsEntity>> execute({
    required String email,
    required String password,
  }) async {
    // try {
    // return await repository.loginUser(email, password);
    // return Future.delayed(const Duration(seconds: 5)).then((value) {
    return const Right(UserDetailsEntity(
      email: 'value.email',
      name: 'value.name',
      userID: 'value.userID',
    ));
    // });

    // });
    // } on SocketException {
    //   return const Left(SocketException(exception: 'No Internet Connection'));
    // } on HttpException {
    //   return const Left(HttpException(exception: '404 Not Found'));
    // } on FormatException {
    //   return const Left(FormatException(exception: 'Invalid Response Format'));
    // }
    // return const Left(HttpException(exception: '404 Not Found'));
  }
}
