import 'package:clear_architecture/features/user_authentication/domain/entities/user_details_entity.dart';
import 'package:dartz/dartz.dart';

import '../../../../core/error/failures.dart';

abstract class UserRepository {
  Future<Either<Failure, UserDetailsEntity>> loginUser(email, password);
  Future<Either<Failure, UserDetailsEntity>> fetchUserdetails(userID);
  Future<Either<Failure, bool>> logoutUser();
}
