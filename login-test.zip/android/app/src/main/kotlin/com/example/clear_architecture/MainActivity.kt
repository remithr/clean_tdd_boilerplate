package com.example.clear_architecture

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
